package com.practica.practicafinalm8uf1

class DetailActivity {
}